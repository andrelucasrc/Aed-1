#include <stdlib.h>
#include <stdio.h>

int main()
{
    printf("\n\tPrograma feito com o objetivo de mostrar os numeros de dez ate um\n");

    for(int c=10; c>=1; c-=1)
        printf("\n\t%d",c);

    printf("\n\n\tFim\n");

    exit(0);
}
