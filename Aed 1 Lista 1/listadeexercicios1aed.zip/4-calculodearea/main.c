#include <stdio.h>
#include <stdlib.h>

int main()
{
    float raio = 5;
    float pi = 3.14;
    float area = pi*raio*raio;

    printf("\n\tUm circulo cujo o raio seja igual a %f",raio);
    printf("\n\te tendo como valor aproximado de pi %f",pi);
    printf("\n\ttem como area o valor %f",area);
    printf("\n");

    return 0;
}
