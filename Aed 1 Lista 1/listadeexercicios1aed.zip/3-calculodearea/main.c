#include <stdio.h>
#include <stdlib.h>

int main()
{
    float lado = 10;
    float area = lado*lado;

    printf("\n\tUm quadrado com lado igual a %f",lado);
    printf("\n\ttem sua area igual a %f",area);
    printf("\n");

    return 0;
}
