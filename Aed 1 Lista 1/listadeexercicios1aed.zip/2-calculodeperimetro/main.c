#include <stdio.h>
#include <stdlib.h>

int main()
{
    float lado = 7;
    float perimetro = lado*4;

    printf("\n\tUm quadrado com lados igual a %f",lado);
    printf("\n\ttem um perimetro igual a %f",perimetro);
    printf("\n");

    return 0;
}
