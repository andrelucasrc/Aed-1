#include <stdlib.h>
#include <stdio.h>

int main()
{
   float altura = 1.65;
   float formula = (72.7*altura)-58;

   printf("\n\tO peso ideal de pessoas do genero masculino");
   printf("\n\te que tenham altura de aproximadamente %fm",altura);
   printf("\n\ttem como seu valor %fKg",formula);
   printf("\n");

   return 0;
}
