#include <stdio.h>
#include <stdlib.h>

int main()
{
    float base = 3.5;
    float altura = 2.0;
    float perimetro = (base+altura)*2;

    printf("\n\tUm retangulo de base %f",base);
    printf("\n\te altura %f",altura);
    printf("\n\ttem como perimetro o valor %f",perimetro);
    printf("\n");

    return 0;
}
