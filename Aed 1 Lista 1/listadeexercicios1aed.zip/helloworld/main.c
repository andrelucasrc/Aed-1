#include <stdlib.h>
#include <stdio.h>

int main()
{
    printf("\n\tH\n\te\n\tl\n\tl\n\to\n\n\tW\n\to\n\tr\n\tl\n\td\n\t!\n");
    return 0;
}
