#include <stdio.h>
#include <stdlib.h>

int main()
{
    float altura = 1.65;
    float formula = (62.1*altura)-44.7;

    printf("\n\tO peso ideal de pessoas do genero feminino");
    printf("\n\te que tenham altura de aproximadamente %fm",altura);
    printf("\n\ttem como valor %fKg",formula);
    printf("\n")

    return 0;
}
