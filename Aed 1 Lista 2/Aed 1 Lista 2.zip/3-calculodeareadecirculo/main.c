

int main()
{
    float pi,
          raio,
          area;

    pi= 3.14;

    printf("\n\tDigite o valor do raio: ");
    scanf("%f",&raio);

    area = pi*raio*raio;

    printf("\n\tO valor da area do circulo e de: %f",area);

    return 0;
}
